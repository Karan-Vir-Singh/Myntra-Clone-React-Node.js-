<h1 align="center">
  <img src="https://raw.githubusercontent.com/BharathPadavu/assets/main/myntra-logo.png" alt="Myntra Logo" width="80" />
  <br>
  Myntra Clone - React + Vite + Express
</h1>

<p align="center">
  <img src="https://img.shields.io/badge/React-18.2-blue?logo=react&logoColor=white" />
  <img src="https://img.shields.io/badge/Vite-4.x-brightgreen?logo=vite" />
  <img src="https://img.shields.io/badge/Redux--Toolkit-1.9.7-764ABC?logo=redux&logoColor=white" />
  <img src="https://img.shields.io/badge/Bootstrap-5.3-purple?logo=bootstrap&logoColor=white" />
  <img src="https://img.shields.io/badge/Node.js-18+-green?logo=node.js&logoColor=white" />
  <img src="https://img.shields.io/badge/Express-4.18-red?logo=express&logoColor=white" />
</p>

---

### ✨ Project Overview
A **Myntra-style shopping website** built with **React + Vite** on the frontend and **Node.js + Express** on the backend. It lets users browse products and manage their shopping bag - similar to how an online store works.

---

### 🚀 Tech Used
- ⚛️ **React + Vite** for fast and modern UI
- 🧩 **Redux Toolkit** for state management
- 🎨 **Bootstrap 5** for responsive design
- 🖥️ **Node.js + Express** for backend API

---

### 💡 Features
- 🛒 Browse all products on the Home page
- 👜 Add or remove items from the Bag page
- 💰 View total price and convenience fee instantly
- 🔄 Live data fetched from backend using Express API
- ⚡ Fast and lightweight frontend powered by Vite

---

### 🧠 How It Works
1. The **Home Page ("/")** displays all items fetched from the backend.  
2. When you click **Add to Bag**, the item is stored in Redux state.  
3. The **Bag Page ("/bag")** shows all selected items with total and convenience fee.

---

### ⚙️ Setup Instructions
```bash
# Clone the repo
git clone https://github.com/BharathPadavu/myntra-clone.git
cd myntra-clone-react-main

# Backend setup
cd backend
npm install
npm start   # runs on http://localhost:8080

# Frontend setup
cd ../frontend
npm install
npm run dev   # runs on http://localhost:5173
```
Then open the frontend URL to explore your Myntra Clone 💻

---

### 🌐 API Endpoints
| Method | Endpoint | Description |
|--------|-----------|-------------|
| **GET** | `/items` | Fetch all products |
| **GET** | `/items/:id` | Fetch single product by ID |
| **POST** | `/items` | Add new product |

---

### ⚠️ Limitations
- Only two routes available: **"/" (Home)** and **"/bag" (Bag Page)**.  
- Basic demo - no authentication, search, or filters yet.  
- Products stored in a JSON file (not a real database).

---

### 🌱 Future Improvements
- 🔍 Add product search & filter options
- 🔐 Add user authentication
- 🧾 Connect with a database (MongoDB)
- 📱 Improve mobile responsiveness

---

<p>
  <a href="https://github.com/BharathPadavu" target="_blank">
    <img src="https://img.shields.io/badge/GitHub-Bharath%20P-black?logo=github&logoColor=white&style=for-the-badge" alt="GitHub Profile"/>
  </a>
</p>

<p>
  <img src="https://img.shields.io/badge/Made%20with%20❤️%20by-Bharath%20P-red"/>
</p>

> ⭐ If you like this project, don’t forget to star it on GitHub!
